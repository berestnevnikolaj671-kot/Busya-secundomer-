package com.webtoapp.generated

object AppConfig {
    const val APP_NAME = "Busya secundomer/секундомер"
    const val TARGET_URL = ""

    const val ACTIVATION_ENABLED = false
    val ACTIVATION_CODES = listOf()

    const val AD_BLOCK_ENABLED = false
    val AD_BLOCK_RULES = listOf()

    const val ANNOUNCEMENT_ENABLED = true
    const val ANNOUNCEMENT_TITLE = "Внимание!"
    const val ANNOUNCEMENT_CONTENT = "Чтобы система не "усыпила" секундомер, и чтобы вы услышали звуковой сигнал по окночанию необходимо зайти в настройки 🔜 экран и яркость 🔜 автоотключение и поставь "никогда" (или Never) или установите маскимальное доступное значение."
    const val ANNOUNCEMENT_LINK = ""
    const val ANNOUNCEMENT_SHOW_ONCE = true

    const val JAVASCRIPT_ENABLED = true
    const val DOM_STORAGE_ENABLED = true
    const val ZOOM_ENABLED = true
    const val DESKTOP_MODE = false
}